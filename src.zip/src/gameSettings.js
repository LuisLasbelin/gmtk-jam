const settings = {
    landTiles: [91, 16, 17, 18, 42, 13, 12, 29, 45, 33, 32],
    ceilingTiles: [91, 16, 17, 18, 42, 13, 12]
}

export default settings;